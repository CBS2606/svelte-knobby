# auto_route_generator

### A generator for [auto_route](https://pub.dev/packages/auto_route) library.
